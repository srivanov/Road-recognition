function [] = ivc(filename)
    video = VideoReader(filename);
    figure;
    cont = 0;
    first = 1;
    recto = 0;
    delay = 10;
    while hasFrame(video)
        frame = readFrame(video);
        gris = rgb2gray(frame);  
        if mod(cont,delay) == 0
            %aplicamos filtro de media
            filtro = fspecial('average');
            sin = imfilter(gris,filtro);
            open = imopen(sin, strel('square', 15));
            bw = im2bw(open, graythresh(gris));
            bw = bwareaopen(bw, 5000);
            cc = bwconncomp(bw);
            L = labelmatrix(cc);
            stats = regionprops(cc, 'Area');
            a = [stats.Area];
            [M I] = max(a);
            idx = I;
            amax = ismember(L, idx);
            stats2 = regionprops(amax, 'Centroid');
            centro = [stats2.Centroid];
            if first == 1;
                recto = centro(:,1);
                first = 0;
            end
            f = int32(centro(:,1));
            mTextBox = uicontrol('style','text','Position', [80 50 70 20]);
            set(mTextBox,'BackgroundColor',[1 1 1]);
            if f < (recto - 45)
                set(mTextBox,'String','IZQUIERDA');
            elseif f > (recto + 45)
                set(mTextBox,'String','DERECHA');
            else
                set(mTextBox,'String','RECTO');
            end
        end
        cont = cont + 1;
        image(frame);
        hold off;
        title('Trabajo IVC', 'FontSize', 10);
        drawnow;
    end
    close;
end